/* David Wilson (862134618) dwils036@ucr.edu
 * Partner: Steven Strickland (862155853) sstri014@ucr.edu 
 * Lab Section: 23
 * Assignment: Lab 4 Exercise 2
 *
 * I acknowledge all content contained herein, excluding template or example
 * code, is my own original work.
 */ 
#include <avr/io.h>

enum numberCruncher {init, incre, decre, reset, wait} state;
unsigned char b0 = 0x00;
unsigned char b1 = 0x00;

void numberEval()
{
	//transitions
	switch(state)
	{
		case init:
			state = wait;
			break;
		case wait:
			if(!b0 && b1)
				state = incre;
			if(b0 && !b1)
				state = decre;
			if(b0 && b1)
				state = reset;
			if(!b0 && !b1)
				state = wait;
			break;
		case incre:
			state = incre;
			break;
		case decre:
			state = decre;
			break;
		case reset:
			state = reset;
			break;
		default:
			state = init;
			break;	
	}
	
	
	switch(state)
	{
		case init:
			break;
		case wait:
			break;
		case incre:
			if(PORTC != 0x09) //limit set to 9
				PORTC = PORTC + 0x01;
			state = wait;
			break;
		case decre:
			if(PORTC != 0x00) //limit set to 0
				PORTC = PORTC - 0x01;
			state = wait;
			break;
		case reset:
			PORTC = 0x00; //hard reset
			state = wait;
			break;
		default: //all cases have be covered
			break;
	}
}

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; //initialize PORT A to 0xFF for input
	DDRC = 0xFF; PORTC = 0x00; //initialize PORT B to 0x00 for output
	
	state = init;
	PORTC = 0x07; //initial starting value for PORTC
	
    while (1)
	{
		b0 = PINA & 0x01; //switch values at this point
		b1 = PINA & 0x02; //switch values at this point
		numberEval();
	}
	return 0;
}