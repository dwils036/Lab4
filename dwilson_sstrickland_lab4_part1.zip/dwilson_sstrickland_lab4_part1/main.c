/*David Wilson (862134618) dwils036@ucr.edu
 * Partner: Steven Strickland sstri014@ucr.edu
 * Lab Section: 023
 * Assignment: Lab 4 Exercise 1
 *
 * I acknowledge all content contained herein, excluding template or example
 * code, is my own original work.
 */ 
#include <avr/io.h>

enum Switch {init, post0, post1, wait} state;
unsigned char P1 = 0x00;

void lightswitch()
{
	
	switch(state)
	{
		case init:
		   if(P1)
				state = post1;
			else
				state = init;
			break;
		case post0: //LED position 1
			if(P1)
				state = post0;
			else
				state = init;
			break;
		case post1: //LED position 2
			if(P1)
				state = post1;
			else
				state = wait;
			break;
		case wait: //loop on wait for proper PINA input
			if(P1)
				state = post0;
			else
				state = wait;
			break;
		default:
			state = init;
			break;	
	}
	
	//actions
	switch(state)
	{
		case init:
			PORTB = 0x01;
			break;
		case post0:
			PORTB = 0x01;
			break;
		case post1:
			PORTB = 0x02;
			break;
		case wait:
			PORTB = 0x02;
		default:
			break;
	}
}

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; // initialize Port A to be input
	DDRB = 0xFF; PORTB = 0x00; // initialize Port B to be output
	
	state = init;
	
    while (1)
	{
		P1 = PINA & 0x01; //switch positions here
		lightswitch();
	}
	return 0;
}