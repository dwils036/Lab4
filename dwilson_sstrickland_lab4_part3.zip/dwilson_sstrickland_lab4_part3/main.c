/*David Wilson (862134618) dwils036@ucr.edu
 * Partner: Steven Strickland sstri014@ucr.edu
 * Lab Section: 023
 * Assignment: Lab 4 Exercise 3
 *Combination lock
 * I acknowledge all content contained herein, excluding template or example
 * code, is my own original work.
 */ 


#include <avr/io.h>

enum doorLock {init, wait0, wait1, unlock, reset} state;
unsigned char b0 = 0x00; //X 
unsigned char b1 = 0x00; //Y 
unsigned char b2 = 0x00; //# 

unsigned char lockB = 0x00; // button to lock while inside

void combiCheck()
{
	//transitions
	switch(state)
	{
		case init:
			state = wait0;
			break;
		case wait0:
			if((b2 && b1) || (b0) || (b1)) // #&&Y||X||Y reset
				state = reset;
			else
				state = wait1; //first state unlock
			break;
		case wait1:
			if(!b1 && b2) // !Y&&# reset
				state = reset;
			if(b1 && !b2) // Y&&!# second state unlock
				state = unlock;
			break;
		case unlock:
			if(!lockB) //door stays unlocked until a7 pressed
				state = unlock;
			if(lockB) //door locks when a7 pressed
				state = reset;
			break;
		case reset:
			state = wait0;
			break;
		default:
			state = init;
			break;	
	}
	
	//actions
	switch(state)
	{
		case init:
			break;
		case wait0:
			break;
		case wait1:
			break;
		case unlock:
			PORTB = 0x01;
			break;
		case reset:
			PORTB = 0x00;
			break;
		default:
			break;
	}
}

int main(void)
{
	
	DDRA = 0x00; PORTA = 0xFF; //initialize to 0xFF for input
	DDRB = 0xFF; PORTB = 0x00; //initialize to 0x00 for output
	DDRC = 0xFF; PORTC = 0x00; //initialize to 0x00 for output
	
	state = init;
	
    while (1)
	{
		b0 = PINA & 0x01; //X
		b1 = PINA & 0x02; //Y
		b2 = PINA & 0x04; //#
		lockB= PINA & 0x80; //button to lock while inside
		combiCheck(); // check combination
	}
		
	return 0;
}

